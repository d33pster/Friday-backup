class NoAudio(Exception):
    pass